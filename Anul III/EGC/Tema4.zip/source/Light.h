#pragma once

#include "includes.h"


enum LightType {
	Omni,
	Spot
};

class Light {

	public:
		Light(int id, LightType type);
		~Light();

		void render();
		void switchState();
		void setProperties(Vector4D ambient, Vector4D diffuse, Vector4D specular, Vector4D position);
		void setProperty(GLenum pname, Vector4D V);

	public:

		int id;
		int type;
		bool enabled;

		Vector4D diffuse;
		Vector4D ambient;
		Vector4D specular;
		Vector4D position;
		Vector3D direction;

};

