#pragma once

#include "Player.h"
#include "Camera.h"
#include "VBO.h"
#include "Object3D.h"
#include "Asteroid.h"
#include "ColorPicker.h"
#include "Light.h"
#include "Missile.h"

/*
 * Class World
 */

class World {
	public:
		World();
		~World();

		// initializare
		void init();

		// creare camere
		void createCameras();

		// schimbare camera de vizualizare
		void switchCamera();

		// actualizeaza parametrii camere
		void updateCamera();

		// selectare camera asteroid
		void asteroidCamera();

		// actualizare pozitie nava
		void updatePlayerPos(float dir, int type);

		// generare asteroizi
		void createAsteroids();

		// initializare lumini
		void initLights();

		// actualizare parametrii lumini
		void updateLights();

		// dezactivare lumini omnidirectionale
		void switchLights();

		// desenare frame
		void render();

		// desenare in framebuffer pentru selectare
		void drawSelectable();

		// selectare obiect
		void pickObject(int x, int y);

		// obiect selectat
		void getSelected(Vector3D V);

		// desenare axe generale
		void drawAxis();

		// desenare spatiu de joc
		void drawSpace();

		// Inaintarea player
		void moveForward(float dir);

		// Miscarea laterala player
		void moveRight(float dir);

		// Miscarea laterala player
		void moveUp(float dir);

		// coliziuni
		void collision();

		// actualizeaza poziti arme
		void updateMissiles();

	public:

		float dir;

		vector<Camera*> cameras;
		vector<Light*> lights;
		Camera *camera;
		int cameraID;

		Asteroid* A;
		vector<Asteroid*> asteroids;

		SpaceCraft *Normandy;
		vector<Missile*> missiles;

		int draw_asteroids_cage;
		
};

