#pragma once

#include "includes.h"

class VBO {

	public:
		VBO(int nr_vertices, GLfloat *vertices, GLfloat *normals);
		~VBO();

		void draw();

	public:
		int nr_vertices;
		GLuint vboId;
		GLsizeiptr size;

};

