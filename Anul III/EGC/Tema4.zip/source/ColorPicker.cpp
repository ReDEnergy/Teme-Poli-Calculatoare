#pragma once

#include "ColorPicker.h"


ColorPicker* ColorPicker::instance = NULL;

ColorPicker::ColorPicker() {
	color = Vector3D(0, 0, 0);
}

ColorPicker::~ColorPicker() {
	instance = NULL;
}

ColorPicker* ColorPicker::getInstance() {
	if (instance != NULL)
		return instance;

	instance = new ColorPicker();

	return instance;
}

Vector3D ColorPicker::getPickColor() {

	color.x++;

	if(color.x == 256) {
		color.x = 0;
		color.y++;
	}

	if(color.y == 256) {
		color.y = 0;
		color.z++;
	}

	return Vector3D(color);
}




