#pragma once

#include <fstream>
#include "includes.h"
#include "Object3D.h"
#include "Asteroid.h"

/*
 * Class Player
 */

class Missile : public Object3D {
	public:
		Missile(char *file);
		Missile::Missile(Missile *A);
		~Missile();

		void init();
		void draw();
		void travel();
		void setPosition(Vector3D pos);
		void moveToTarget();

	public:

		Vector3D dir;
		Vector3D rotate;
		Vector3D position;
		Asteroid *target;

		float speed;
		float scale;
		float angle;
		float angleOX;
		float angleOY;
};