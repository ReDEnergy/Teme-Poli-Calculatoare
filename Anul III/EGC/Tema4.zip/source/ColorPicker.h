#pragma once

#include "includes.h"

class ColorPicker {

	private:
		ColorPicker();
		ColorPicker(ColorPicker &copy);
		ColorPicker& operator= (ColorPicker const &copy);

	public:
		~ColorPicker();

		static ColorPicker* getInstance();
		static ColorPicker* instance;

		Vector3D getPickColor();

	private:
		Vector3D color;
		

};

