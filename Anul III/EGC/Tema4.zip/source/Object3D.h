#pragma once

#include <fstream>
#include "includes.h"
#include "VBO.h"


/*
 * Class Object3D
 */

class Object3D {
	public:
		Object3D();
		Object3D(char *file);
		Object3D(Object3D *O);
		virtual ~Object3D();

		void createVBO();
		void drawVBO();
		virtual void drawCage();

	private:

		void readObj(char *file);
		void createVBOArrays();
		void getCenter();

	public:

		Vector3D center;
		float radius;

	private:

		VBO *V;

		vector <float> v_vertices;
		vector <float> v_normals;
		vector <int> v_faces;

		float *vertices;
		float *normals;
};

