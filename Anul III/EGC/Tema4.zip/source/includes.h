#pragma once

#define _USE_MATH_DEFINES

#include <cstdio>
#include <iostream>
#include <cstdlib>
#include <cmath>
#include <cstdlib>
#include <vector>
#include <ctime>

//#pragma comment(lib, "freeglut.lib")
#pragma comment(lib, "glew32.lib")

#include "glew.h"
#include "wglew.h"
#include "freeglut.h"

#include "Vector3D.h"
#include "Vector4D.h"

using namespace std;

