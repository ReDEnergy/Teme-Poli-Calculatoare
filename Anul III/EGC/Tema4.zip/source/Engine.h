#pragma once

#include "includes.h"
#include "Camera.h"
#include "World.h"


using namespace std;

const int ESC = 27;

/*
 *	Mic Engine Grafic
 */

class Engine {
	public:

		static void glutIdle();
		static void init(int argc, char **argv);
		static void display();
		static void reshape(int width, int height);
		static void onKey();
		static void reset();

		// Functia returneaza timpul trecut de la inceputul randarii jocului pana in prezent
		static int getElapseTime();

		// Functii pentru KeyBuffering
		static void keyPressed(unsigned char key, int x, int y);
		static void keyUp(unsigned char key, int x, int y);
		static void specialKeyPressed(int key, int x, int y);
		static void specialKeyUp(int key, int x, int y);

		// Mouse actions
		static void mouseClick(int button, int state, int x, int y);
		static void mouseMotion(int x, int y);
		static void mouseWheelFunc(int wheel, int direction, int x, int y);
		static void clipCursor();

	public:

		static World *world;

		static int elapse_time;
		static int frames;
		static int level;
		static int youarestupid;

		// Windows settings
		static RECT window;
		static int sizeX;
		static int sizeY;
		static bool clip_cursor;

		// Vectorul de buffering pentru tastele apasate
		static bool *keyStates;
		static bool *skeyStates;

		static Camera *camera;

		// Callback pentru mouse
		static int mouseX;
		static int mouseY;
};


