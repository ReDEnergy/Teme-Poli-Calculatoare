//#pragma comment(lib, "opengl32.lib")
//#pragma comment(lib, "glu32.lib")
//#pragma comment(lib, "glut32.lib")

#include "includes.h"
#include "Engine.h"

/*
 *	SpaceEscape
 *	TEMA 4 EGC
 *	IVANICA GABRIEL 333CA
 */

int main(int argc, char *argv[]) {

	srand(unsigned int(time(NULL)));

	Engine::init(argc, argv);

	return 0;
}