#define _USE_MATH_DEFINES

#pragma once
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <cmath>

#include "Vector3D.h"

/*
 *	Tipuri de Camera View suportate
 */
enum CameraType {
	FirstPerson,
	ThirdPerson,
	TopView
};

/*
 *	Clasa ce implementeaza camera
 */
class Camera{
	public:
		Camera(float distance);
		~Camera();

		void init();
		void render();

		// Rotatii FPS
		void rotateFPS_OX(float angle);
		void rotateFPS_OY(float angle);
		void rotateFPS_OZ(float angle);

		// Rotatii TPS
		void rotateTPS_OX(float angle);
		void rotateTPS_OY(float angle);
		void rotateTPS_OZ(float angle);

		// Rotatie generala
		void rotateOX(float dir);
		void rotateOY(float dir);

		// Zoom
		void moveCloser(float add);
		void switchView(int camera_type);

		// Speed
		void increaseSpeed();
		void decreaseSpeed();

		// Translatare dupa vectorii camerei
		void translateForward(float dist);
		void translateRight(float dist);
		void translateUp(float dist);
		void translateAfterVector(Vector3D V, float dist);

		// Translatare pe plan orizontal
		void moveForward(float dir);
		void moveRight(float dir);
		void moveUp(float dir);
		void moveToPosition(Vector3D pos);

		// Target point
		void drawTargetPoint();
		Vector3D getTargetPoint();

	public:
		// Vectori camera
		Vector3D eye;
		Vector3D forward;
		Vector3D right;
		Vector3D up;
		Vector3D target;

		// Mod vizualizare
		int type;

		// Unghiuri de rotatie
		float angle_OX;
		float angle_OY;

		// Distanta targe/zoom maxim/
		float const initial_dist;
		float target_dist;
		float target_max_dist;

		// Limite de rotatie
		float limit_up_FPS;
		float limit_up_TPS;
		float limit_up_TOP;
		float limit_down;

		// Viteza de deplasare si rotatie
		float move_speed;
		float rotate_speed;
};