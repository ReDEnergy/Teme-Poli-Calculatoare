#pragma once

#include <fstream>
#include "includes.h"
#include "Object3D.h"

/*
 * Class Player
 */

class SpaceCraft : public Object3D {
	public:
		SpaceCraft(char *file);
		~SpaceCraft();

		void init();
		void draw();
		void drawCage();
		void selectionDraw();
		void travel();
		void setPosition(Vector3D pos);

	public:

		Vector3D dir;
		Vector3D rotate;
		Vector3D position;

		float shield;
		float speed;
		float scale;
		float angle;
};