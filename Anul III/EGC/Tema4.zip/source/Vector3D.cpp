#pragma once

#include "Vector3D.h"
#include "Vector4D.h"

ostream& operator<< (ostream &os, const Vector3D &V) 
{
	os << "(" << V.x << ", " << V.y << ", " << V.z << ")";
	return os;
}

ostream& operator<< (ostream &os, const Vector4D &V) 
{
	os << "(" << V.x << ", " << V.y << ", " << V.z << ", " << V.a << ")";
	return os;
}