#pragma once

#include <fstream>
#include "includes.h"
#include "Object3D.h"
#include "ColorPicker.h"

/*
 * Class Asteroid
 */

class Asteroid : public Object3D {
	public:
		Asteroid(char *file);
		Asteroid(Asteroid *A);
		~Asteroid();

		void init();
		void draw(int target);
		void travel();

	public:

		Vector3D pickcolor;
		Vector3D dir;
		Vector3D rotate;
		Vector3D position;

		int type;
		float speed;
		float scale;
		float angle;
		float rspeed;
		bool selected;
};