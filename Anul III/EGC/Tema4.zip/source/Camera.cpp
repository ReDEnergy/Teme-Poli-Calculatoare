#include "Camera.h"

// Constructor camera
Camera::Camera(float distance)
	: target_dist(distance),
	initial_dist(distance)
{
}

Camera::~Camera() {}

// Initializare camera
void Camera::init() {

	eye = Vector3D(0, 0, 0);
	forward = Vector3D(0, 0, 1);
	right = Vector3D(1, 0, 0);
	up = Vector3D(0, 1, 0);

	angle_OX = 0;
	angle_OY = 0;

	limit_up_TPS =  0.95f * (float) M_PI / 2;
	limit_up_FPS = -0.95f * (float) M_PI / 2;
	limit_up_TOP =  0.99f * (float) M_PI / 2;

	limit_down =  -0.95f * (float) M_PI / 2;

	type = FirstPerson;

	move_speed = 0.5f;
	rotate_speed = 0.005f;

	target_max_dist = 200;	

	rotateFPS_OY((float) -M_PI_2);
}

/*
 *	Glut Camera Render
 */

void Camera::render()
{
	Vector3D center = eye + forward;
	gluLookAt(eye.x, eye.y, eye.z, center.x, center.y, center.z, up.x, up.y, up.z);

	if (type != FirstPerson)
		drawTargetPoint();
}


void Camera::increaseSpeed() {
	if (move_speed > 10)
		return;
	move_speed *= 1.1;
}

void Camera::decreaseSpeed() {
	if (move_speed < 0.1f)
		return;
	move_speed /= 1.1;
}

/*
 * First Person Camera View
 */
void Camera::rotateFPS_OY(float angle)
{

	forward.rotateOY(angle);
	right.rotateOY(angle);
	up.rotateOY(angle);

	angle_OY += angle;

	if (angle_OY > 2 * (float) M_PI)
		angle_OY -= 2 * (float) M_PI;

	if (angle_OY < 0)
		angle_OY += 2 * (float) M_PI;

}

void Camera::rotateFPS_OX(float angle)
{

	if (angle_OX + angle >= limit_up_TPS && type != TopView)
		return;

	if (angle_OX + angle <= limit_down && type == ThirdPerson)
		return;

	if (angle_OX + angle <= limit_up_FPS && type == FirstPerson)
		return;

	angle_OX += angle;

	up = up * cos(angle) + forward * sin(angle);
	forward = up.CrossProduct(right);

}

void Camera::rotateFPS_OZ(float angle)
{
	right = right * cos(angle) + up * sin(angle);
	up = right.CrossProduct(forward);
}

/*
 * Move Camera Eye Poition
 */
void Camera::translateForward(float dist)
{
	eye += forward * dist;
}

void Camera::translateRight(float dist)
{
	eye += right * dist;
}

void Camera::translateUp(float dist)
{
	eye += Vector3D(0, 1, 0) * dist;
}

void Camera::translateAfterVector(Vector3D V, float dist) {
	eye += V * dist;
}

/*
 * 3rd Person Camera View
 */
void Camera::rotateTPS_OX(float angle) 
{
	translateForward(target_dist);
	rotateFPS_OX(angle);
	translateForward(-target_dist);
}

void Camera::rotateTPS_OY(float angle) 
{

	translateForward(target_dist);
	rotateFPS_OY(angle);
	translateForward(-target_dist);

}

void Camera::rotateTPS_OZ(float angle)
{
	translateForward(target_dist);
	rotateFPS_OZ(angle);
	translateForward(-target_dist);
}


/*
 * Move Camera after target
 */

void Camera::moveForward(float dir) {
	Vector3D front = Vector3D(forward);

	front.y = 0;
	front.Normalize();
	eye += front * dir * move_speed;
}

void Camera::moveRight(float dir) {
	Vector3D side = Vector3D(right);

	side.y = 0;
	side.Normalize();
	eye += side * dir * move_speed;
}

void Camera::moveUp(float dir) {
	translateUp(dir * move_speed);
}

// Repozitionare camera la coordonatele date
void Camera::moveToPosition(Vector3D pos) {

	Vector3D OX = Vector3D(1, 0, 0);
	Vector3D OY = Vector3D(0, 1, 0);
	Vector3D OZ = Vector3D(0, 0, 1);

	int mode = type;

	switchView(FirstPerson);

	translateAfterVector(OX, pos.x - eye.x);
	translateAfterVector(OY, pos.y - eye.y);
	translateAfterVector(OZ, pos.z - eye.z);

	switchView(mode);
}


/*
 *	Update Camera View
 */

void Camera::rotateOX(float dir) {

	if (type == TopView)
		return;

	if (type == FirstPerson)
		rotateFPS_OX(dir * rotate_speed);

	if (type == ThirdPerson)
		rotateTPS_OX(-dir * rotate_speed);
}

void Camera::rotateOY(float dir) {

	if (type == TopView)
		rotateTPS_OY(-dir * rotate_speed);

	if (type == FirstPerson)
		rotateFPS_OY(dir * rotate_speed);

	if (type == ThirdPerson)
		rotateTPS_OY(-dir * rotate_speed);
}

void Camera::moveCloser(float add)
{
	if (type == FirstPerson)
		return;

	if (target_dist + add <= 0.5f)
		return;

	if (target_dist + add > target_max_dist)
		return;

	target_dist += add;
	eye -= forward * add;
}


/*
 * Update Camera Mode
 */

void Camera::switchView(int camera_type)
{
	if (camera_type == type)
		return;

	if (camera_type == FirstPerson) {
		type = ThirdPerson;
		moveCloser(initial_dist - target_dist);
	}

	if (camera_type == ThirdPerson) {

		if (type == TopView) {
			type = ThirdPerson;
			rotateTPS_OX(-angle_OX + (float) M_PI/4);
			return;
		}

		type = FirstPerson;
	}

	// Switch to TopView
	if (camera_type == TopView) {

		if (type == ThirdPerson)
			eye = eye + forward * target_dist;

		type = TopView;

		rotateFPS_OX(-angle_OX + limit_up_TOP);
		rotateFPS_OY(-angle_OY);
		eye = eye - forward * target_dist;
		
		moveCloser(target_max_dist/2 - target_dist);
		return;
	}


	// Switch to FirstPerson
	if (type == ThirdPerson) {
		glutSetCursor(0);
		type = FirstPerson;
		eye = eye + forward * target_dist;
		rotateFPS_OX(-angle_OX);
		return;
	}

	// Switch to ThirdPerson
	if (type == FirstPerson) {
		glutSetCursor(GLUT_CURSOR_NONE);
		type = ThirdPerson;
		rotateFPS_OX(-angle_OX + (float) M_PI/16);
		eye = eye - forward * target_dist;
		return;
	}
}


/*
 *	Camera Target
 */

Vector3D Camera::getTargetPoint() {

	if (type == FirstPerson)
		return Vector3D(eye);

	return Vector3D(eye + forward * target_dist);
}

// Desenare Target
void Camera::drawTargetPoint() {

	glColor4f(0.7f, 0.95f, 0.1f, 1);

	target = eye + forward * target_dist;

	// Target point
	glPushMatrix();
		glTranslatef(target.x, target.y, target.z);
		glutSolidSphere(0.1f, 30, 30);
		glTranslatef(-target.x, -target.y, -target.z);
	glPopMatrix();

}