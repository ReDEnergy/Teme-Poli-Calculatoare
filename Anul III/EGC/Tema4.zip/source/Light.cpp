#include "Light.h"

Light::Light(int id, LightType type) 
	: id(id)
{

	enabled = true;

	diffuse = Vector4D(4, 4, 4, 1);
	ambient = Vector4D(0, 0, 0, 0);
	specular = Vector4D(1, 1, 1, 1);
	position = Vector4D(0, 0, 0, 0);
	direction = Vector3D(0, 0, -1);

	// atenuari standard
	glLightf(GL_LIGHT0 + id, GL_CONSTANT_ATTENUATION, 1);
	glLightf(GL_LIGHT0 + id, GL_LINEAR_ATTENUATION, 0.2f);

	// parametrii lumina
	glLightfv(GL_LIGHT0 + id, GL_DIFFUSE, diffuse.Array());
	glLightfv(GL_LIGHT0 + id, GL_AMBIENT, ambient.Array());
	glLightfv(GL_LIGHT0 + id, GL_SPECULAR, specular.Array());
	glLightfv(GL_LIGHT0 + id, GL_POSITION, position.Array());

	if(type == Spot)
	{
		glLightf(GL_LIGHT0 + id, GL_SPOT_CUTOFF, 30.0);
		glLightf(GL_LIGHT0 + id, GL_SPOT_EXPONENT, 2);
		glLightfv(GL_LIGHT0 + id, GL_SPOT_DIRECTION, direction.Array());      
	}
}

void Light::render() {
	glColor3f(1, 1, 1);

	if (enabled)
		glEnable(GL_LIGHT0 + id);
	else 
		glDisable(GL_LIGHT0 + id);

	glTranslatef(position.x, position.y, position.z);
		glutSolidSphere(0.2f, 16, 16);
	glTranslatef(-position.x, -position.y, -position.z);

}

void Light::switchState() {
	enabled = !enabled;
}

void Light::setProperties(Vector4D ambient, Vector4D diffuse, Vector4D specular, Vector4D position) {

	glLightfv(GL_LIGHT0 + id, GL_DIFFUSE, diffuse.Array());
	glLightfv(GL_LIGHT0 + id, GL_AMBIENT, ambient.Array());
	glLightfv(GL_LIGHT0 + id, GL_SPECULAR, specular.Array());
	glLightfv(GL_LIGHT0 + id, GL_POSITION, position.Array());

	this->ambient = ambient;
	this->diffuse = diffuse;
	this->specular = specular;
	this->position = position;
}

void Light::setProperty(GLenum pname, Vector4D V) {
	glLightfv(GL_LIGHT0 + id, pname, V.Array());
}

