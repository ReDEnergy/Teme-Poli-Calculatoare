#include "Object3D.h"


Object3D::Object3D () {

}


Object3D::Object3D (char *file) 
{
	readObj(file);
	getCenter();
	createVBOArrays();
}


Object3D::Object3D(Object3D *O) {
	V = O->V;
	center = O->center;
	radius = O->radius;
}

Object3D::~Object3D() {

	delete vertices;
	delete normals;
}


void Object3D::drawVBO() {

	glTranslatef(-center.x, -center.y, -center.z);
		V->draw();
	glTranslatef(center.x, center.y, center.z);

}

void Object3D::drawCage() {
	glColor4f(1, 1, 1, 0.1f);
	glutSolidSphere(radius, 16, 16);
}

void Object3D::readObj(char *file) {

	char line[256];
	char word[50];
	float vertex;
	int index;

	fstream fin;
	fin.open(file, fstream::in);


	while(!fin.eof()) {
		
		fin>>word;

		if(word[0] == '#') {
			fin.getline(line, 256);
			continue;
		}

		if (strcmp(word, "v") == 0) {
			for(int i=0; i<3; i++) {
				fin>>vertex;
				v_vertices.push_back(vertex);
			}
			continue;
		}

		if (strcmp(word, "vn") == 0) {
			for(int i=0; i<3; i++) {
				fin>>vertex;
				v_normals.push_back(vertex);
			}
			continue;
		}

		if (strcmp(word, "f") == 0) {
			for(int i=0; i<9; i++) {
				fin>>index;
				v_faces.push_back(index);

				fin.get(word[0]);
			}

			fin.getline(line, 256);

			continue;
		}

		fin.getline(line, 256);

	}

	fin.close();

}

void Object3D::getCenter() {

	float min =  -1000000;

	Vector3D vmax = Vector3D(min, min, min);
	Vector3D vmin = -vmax;

	int size = v_vertices.size();

	for (int i=0; i<size; i+=3) {
		vmin.x = min(vmin.x, v_vertices[i]);
		vmax.x = max(vmax.x, v_vertices[i]);

		vmin.y = min(vmin.y, v_vertices[i+1]);
		vmax.y = max(vmax.y, v_vertices[i+1]);

		vmin.z = min(vmin.z, v_vertices[i+2]);
		vmax.z = max(vmax.z, v_vertices[i+2]);
	}

	center = (vmax+vmin) / 2;

	vmax -= center;

	radius = max(vmax.x, vmax.y);
	radius = max(radius, vmax.z);
}

void Object3D::createVBOArrays() {

	int size = v_faces.size();

	vertices = new float[size];
	normals = new float[size];

	int k = 0;
	int v , n;

	for (int i=0; i<size; i+=3) {
		
		v = v_faces[i]-1;
		n = v_faces[i+2]-1;

		for (int j=0; j<3; j++) {
			vertices[k] = v_vertices[v * 3 + j];
			normals[k] = v_normals[n * 3 + j];
			k++;
		}
	}
}

void Object3D::createVBO() {

	int size = v_faces.size() / 3;

	V = new VBO(size, vertices, normals);
}