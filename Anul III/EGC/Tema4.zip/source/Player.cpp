#include "Player.h"



SpaceCraft::SpaceCraft(char *file)
	: Object3D(file)
{
	init();
	createVBO();
	speed = 0.1f;
}


SpaceCraft::~SpaceCraft() 
{
}

void SpaceCraft::init() {
	angle = 0;
	scale = 0.5f;
	shield = 0.25f;
	position = Vector3D(0, 0, 0);
	rotate = Vector3D(0, 1, 0);
}

void SpaceCraft::draw() {

	glColor4f(1, 1, 1, 0.2f);

	glTranslatef(position.x, position.y, position.z);
	glRotatef(angle, rotate.x, rotate.y, rotate.z);
	glScalef(scale, scale, scale);
		drawVBO();
		drawCage();
	glScalef(1/scale, 1/scale, 1/scale);
	glRotatef(-angle, rotate.x, rotate.y, rotate.z);
	glTranslatef(-position.x, -position.y, -position.z);

}

void SpaceCraft::setPosition(Vector3D pos) {
	position = pos + Vector3D(0, -1, 0);
}

void SpaceCraft::drawCage() {
	glColor4f(0.2f, 0.5f, 0.8f, shield);
	glutSolidSphere(radius, 128, 128);
}