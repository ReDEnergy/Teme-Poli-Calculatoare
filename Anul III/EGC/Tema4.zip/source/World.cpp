#include "World.h"

/*
 * Constructor
 */ 
World::World() {

}

/*
 * Initializare spatiu de joc
 */ 
void World::init() {

	initLights();

	createCameras();

	Normandy = new SpaceCraft("./obj/normandy.obj");

	Missile *M = new Missile("./obj/missile.obj");
	missiles.push_back(M);
	missiles.push_back(new Missile(M));

	createAsteroids();

	draw_asteroids_cage = 0;
}

/*
 * Generare asteroizi
 */ 
void World::createCameras() {

	cameraID = 0;

	for (int i=0; i<2; i++) {
		camera = new Camera(20);
		camera->init();
		cameras.push_back(camera);
	}

	camera = cameras[cameraID];
	camera->translateUp(1);

}

/*
 * Initializare lumini
 */ 

void World::initLights() {

	Vector4D ambient = Vector4D(0, 0, 0, 1);
	Vector4D diffuse = Vector4D(0.8f, 0.68f, 0.4f, 0);
	Vector4D specular = Vector4D(0.2f, 0.2f, 0.2f, 0);
	Vector4D position = Vector4D(0, 50, 100, 0);

	Light *L = new Light(0, Omni);
	L->setProperties(ambient, diffuse, specular, position);
	lights.push_back(L);

    ambient = Vector4D(0.3f, 0.3f, 0.3f, 1);
    diffuse = Vector4D(0.25f, 0.56f, 0.68f, 1);
    specular = Vector4D(0.2f, 0.2f, 0.2f, 1);
    position = Vector4D(0, 50, -100, 0);

	L = new Light(1, Omni);
	L->setProperties(ambient, diffuse, specular, position);
	lights.push_back(L);

	ambient = Vector4D(1, 1, 1, 1);
	diffuse = Vector4D(1, 1, 1, 1);
	specular = Vector4D(1, 1, 1, 1);
    position = Vector4D(0, 0, 0, 1);

	L = new Light(2, Spot);
	L->setProperties(ambient, diffuse, specular, position);
	lights.push_back(L);

	L = new Light(3, Spot);
	L->setProperties(ambient, diffuse, specular, position);
	lights.push_back(L);

	L = new Light(4, Spot);
	L->setProperties(ambient, diffuse, specular, position);
	L->direction = Vector3D(0, 0, 1);
	lights.push_back(L);

	L = new Light(5, Spot);
	L->setProperties(ambient, diffuse, specular, position);
	L->direction = Vector3D(0, 0, 1);
	lights.push_back(L);

}

/*
 * Generare asteroizi
 */ 
void World::createAsteroids() {

	A = new Asteroid("./obj/asteroid1.obj");
	asteroids.push_back(A);

	A = new Asteroid("./obj/asteroid2.obj");
	asteroids.push_back(A);

	A = new Asteroid("./obj/asteroid3.obj");
	asteroids.push_back(A);

	for (int i=0; i<150; i++) {
		Asteroid *B = new Asteroid(asteroids[i % 3]);
		asteroids.push_back(B);
	}

	A = new Asteroid("./obj/gift.obj");
	A->type = 1;
	asteroids.push_back(A);
	for (int i=0; i<10; i++)
		asteroids.push_back(new Asteroid(A));

}

/*
 * Miscare fata/spate
 */ 
void World::moveForward(float dir) {
	camera->moveForward(dir);
}

/*
 * Miscare laterala
 */ 
void World::moveRight(float dir) {
	camera->moveRight(dir);
}

/*
 * Miscare pe verticala
 */ 
void World::moveUp(float dir) {
	camera->moveUp(dir);
}

/*
 * Actualizare parametrii camera
 */ 
void World::updateCamera() {

	if (cameraID == 0) {
		Normandy->setPosition(camera->getTargetPoint());
	}

	if (cameraID != 2)
		camera->render();

	else {

		if (A->selected == false) {
			asteroidCamera();
			return;
		}

		Vector3D eye = A->position;
		Vector3D center = Normandy->position;
		gluLookAt(eye.x, eye.y, eye.z, center.x, center.y, center.z, 0, 1, 0);
	}
}

/*
 * Actualizare parametrii lumina
 */ 
void World::updateLights() {

	Vector3D p = Normandy->position;
		
	Vector4D lightS1 = Vector4D(p.x, p.y, p.z, 1) + Vector4D(0.6f, -0.3f,  1.2f, 0);
	Vector4D lightS2 = Vector4D(p.x, p.y, p.z, 1) + Vector4D(0.6f, -0.3f, -1.2f, 0);
	Vector4D lightS3 = Vector4D(p.x, p.y, p.z, 1) + Vector4D( 5.5f, -0.3f,  1.3f, 0);
	Vector4D lightS4 = Vector4D(p.x, p.y, p.z, 1) + Vector4D( 5.5f, -0.3f, -1.3f, 0);

	lights[2]->position = lightS1;
	lights[2]->setProperty(GL_POSITION, lightS1);

	lights[3]->position = lightS2;
	lights[3]->setProperty(GL_POSITION, lightS2);

	lights[4]->position = lightS3;
	lights[4]->setProperty(GL_POSITION, lightS3);

	lights[5]->position = lightS4;
	lights[5]->setProperty(GL_POSITION, lightS4);
}

/*
 * Comutare lumini omnidirectionale
 */ 
void World::switchLights() {
	lights[0]->switchState();
	lights[1]->switchState();
}

/*
 * Actualizare parametrii nava
 */ 
void World::updatePlayerPos(float dir, int type) {

	switchCamera();

	switch(type) {
		case 1 :
			moveForward(dir);
			break;
		case 2 :
			moveRight(dir);
			break;
		case 3 :
			moveUp(dir);
			break;
	}

	updateCamera();

	switchCamera();
}

/*
 * Comutare camera nava/free
 */ 
void World::switchCamera() {

	int prev = cameraID;

	switch(cameraID) {

		case 0 :
			cameraID = 1;

			break;

		case 1 :
			cameraID = 0;
			camera = cameras[cameraID];
			camera->moveToPosition(Normandy->position);
			camera->translateUp(1);
			break;
	}

	camera = cameras[cameraID];
}

/*
 * Comutare camera asteroid
 */ 
void World::asteroidCamera() {
	if (cameraID == 0)
		return;

	if (cameraID == 2) {
		cameraID = 1;
		camera = cameras[cameraID];
		return;
	}

	cameraID = 2;
}

/*
 * Coliziuni asteroizi
 */ 
void World::collision() {

	float Nradius = Normandy->radius * Normandy->scale;

	for (unsigned int i=0; i<asteroids.size(); i++) {

		float radius = asteroids[i]->scale * asteroids[i]->radius;
		float dist = Normandy->position.Distance(asteroids[i]->position);

		if (dist < radius + Nradius) {
			cout<<"Colliziune cu asteroidul : "<<i<<endl;
			asteroids[i]->init();

			if (asteroids[i]->type == 0) {
				if (Normandy->shield > 0)
					Normandy->shield -= 0.025f;
			}
			else
				if (Normandy->shield < 0.8f)
					Normandy->shield += 0.1f;

		}
	}
}

/*
 * Actializare parametrii missiles
 */ 
void World::updateMissiles() {

	if (A->selected == false) {
		missiles[0]->target = NULL;
		missiles[1]->target = NULL;

		Normandy->position;
		
		Vector3D m1 = Normandy->position + Vector3D(3, -0.55f,  1.9f);
		Vector3D m2 = Normandy->position + Vector3D(3, -0.55f, -1.9f);

		missiles[0]->setPosition(m1);

		missiles[0]->angleOX = 0;
		missiles[0]->angleOY = 90;

		missiles[1]->angleOX = 0;
		missiles[1]->angleOY = 90;

		missiles[1]->setPosition(m2);
	}
	else { 
		missiles[0]->moveToTarget();
		missiles[1]->moveToTarget();
	}

}

/*
 * Randare spatiu de joc
 */ 
void World::render() {

	updateCamera();
	updateLights();
	updateMissiles();

	for(unsigned int i=0; i<lights.size(); i++)
		lights[i]->render();

	collision();

	GLfloat params[4] = {0.3f, 0.3f, 0.3f, 0.1f};

	glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, 2);
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, params);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, params);

	drawSpace();
	drawAxis();

	for(unsigned int i=0; i<missiles.size(); i++)
		missiles[i]->draw();


	glEnable(GL_ALPHA_TEST);
	glAlphaFunc(GL_EQUAL, GL_ONE);

	for (unsigned int i=0; i<asteroids.size(); i++) {
		asteroids[i]->travel();
		asteroids[i]->draw(0);
	}

	glAlphaFunc(GL_LESS, GL_ONE);

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_DST_ALPHA);
	
	glDepthMask(GL_FALSE);

		Normandy->draw();

		for (unsigned int i=0; i<asteroids.size(); i++)
			asteroids[i]->draw(draw_asteroids_cage);

	glDepthMask(GL_TRUE);
	glDisable(GL_BLEND);
	glDisable(GL_ALPHA_TEST);

}

/*
 * Selectare obiect utilizand Mouse-ul
 */ 
void World::pickObject(int x, int y) {

	// get color information from frame buffer
	unsigned char pixel[3];
 	GLint viewport[4];

	glDisable(GL_LIGHTING);

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	
	drawSelectable();

	glGetIntegerv(GL_VIEWPORT, viewport);
	glReadPixels(x, viewport[3] - y, 1, 1, GL_RGB, GL_UNSIGNED_BYTE, pixel);

	glEnable(GL_LIGHTING);

	Vector3D color = Vector3D(pixel[0], pixel[1], pixel[2]);
	getSelected(color);
}

/*
 * Denseare obiecte selectabile
 */ 
void World::drawSelectable() {

	for (unsigned int i=0; i<asteroids.size(); i++)
		asteroids[i]->draw(2);

}

/*
 * Selectarea obiect
 */ 
void World::getSelected(Vector3D V) {
	for (unsigned int i=0; i<asteroids.size(); i++) {
		asteroids[i]->selected = false;
		if (asteroids[i]->pickcolor == V) {

			A = asteroids[i];

			A ->selected = true;

			if (cameraID == 0) {
				missiles[0]->target = A;
				missiles[1]->target = A;
			}
		}
	}
}

/*
 * Denseare limita spatiu de joc
 */ 
void World::drawSpace() {
	glLineWidth(3);
	glColor4f(0, 0.3f, 0.5f, 1);
	glScalef(4, 1, 2);
		glutWireCube(100);
	glScalef(0.25f, 1, 0.5f);
}

/*
 * Desenare axe generale
 */ 
void World::drawAxis() {

	float size = 200;

	glLineWidth(3);

	glTranslatef(0, 0.01f, 0);
	glBegin(GL_LINES);
		// Draw X
		glColor4f(1, 0, 0, 1);
		glVertex3f(0, 0, 0);
		glVertex3f(size, 0, 0);

		// Draw Y
		glColor4f(0, 1, 0, 1);
		glVertex3f(0, 0, 0);
		glVertex3f(0, size, 0);

		// Draw Z
		glColor4f(0, 0, 1, 1);
		glVertex3f(0, 0, 0);
		glVertex3f(0, 0, size);
	glEnd();
	glTranslatef(0, -0.01f, 0);
}