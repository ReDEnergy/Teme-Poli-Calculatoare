#include "Engine.h"


bool *Engine::keyStates = new bool[256];
bool *Engine::skeyStates = new bool[256];

// Camera *Engine::camera;
World *Engine::world;

int Engine::frames = 120;

RECT Engine::window;

bool Engine::clip_cursor = false;

int Engine::level = 3;
int Engine::youarestupid = 0;

int Engine::sizeX = 840;
int Engine::sizeY = 480;

int Engine::mouseX = sizeX/2;
int Engine::mouseY = sizeY/2;

int Engine::elapse_time = 0;


/*
 *	Functia de callback pentru apasarea unei taste
 */
void Engine::keyPressed (unsigned char key, int x, int y) {
	if(key == ESC)
		glutExit();

	keyStates[key] = true;

	if (keyStates['c'])
		clipCursor();

	if (keyStates['1'])
		world->camera->switchView(FirstPerson);

	if (keyStates['2'])
		world->camera->switchView(ThirdPerson);

	if (keyStates['3'])
		world->camera->switchView(TopView);

	if (keyStates['r'])
		reset();

	if (keyStates['n'])
		world->switchCamera();

	if (keyStates['m'])
		world->asteroidCamera();

	if (keyStates['l'])
		world->switchLights();

	if (keyStates['j'])
		world->draw_asteroids_cage = 1 - world->draw_asteroids_cage;

	if (keyStates['*'])
		world->camera->increaseSpeed();

	if (keyStates['/'])
		world->camera->decreaseSpeed();

}  

/*
 *	Functia de callback in momentul in care se inceteaza apasarea unei taste 
 */
void Engine::keyUp (unsigned char key, int x, int y) {
	keyStates[key] = false;
}

/*
 *	Functia de callback pentru apasarea unei taste speciale
 */
void Engine::specialKeyPressed (int key, int x, int y) {
	skeyStates[key] = true;
	cout<<"Special key: "<<key<<endl;
}  

/*
 *	Functia de callback in momentul in care se inceteaza apasarea unei taste speciale
 */
void Engine::specialKeyUp (int key, int x, int y) {
	skeyStates[key] = false;
}

// Key actions
void Engine::onKey() {

	float diag = 0.707106f;
	int dir_keys_pressed = 0;

	if (keyStates['w'] && keyStates['a']) {
		world->moveForward(diag);
		world->moveRight(-diag);
		dir_keys_pressed = 2;
	}

	if (keyStates['w'] && keyStates['d']) {
		world->moveForward(diag);
		world->moveRight(diag);
		dir_keys_pressed = 2;
	}

	if (keyStates['s'] && keyStates['a']) {
		world->moveForward(-diag);
		world->moveRight(-diag);
		dir_keys_pressed = 2;
	}

	if (keyStates['s'] && keyStates['d']) {
		world->moveForward(-diag);
		world->moveRight(diag);
		dir_keys_pressed = 2;
	}


	if (keyStates[' '])
		world->moveUp(1);

	if (keyStates['e'])
		world->moveUp(-1);


	if ( dir_keys_pressed != 2 ) {

		if (keyStates['w'])
			world->moveForward(1);

		if (keyStates['a'])
			world->moveRight(-1);

		if (keyStates['s'])
			world->moveForward(-1);

		if (keyStates['d'])
			world->moveRight(1);
	}

	if (keyStates['7'])
		world->updatePlayerPos(-1, 3);

	if (keyStates['9'])
		world->updatePlayerPos(1, 3);

	if (keyStates['8'])
		world->updatePlayerPos(1, 1);

	if (keyStates['4'])
		world->updatePlayerPos(-1, 2);

	if (keyStates['5'])
		world->updatePlayerPos(-1, 1);

	if (keyStates['6'])
		world->updatePlayerPos(1, 2);


	if (keyStates['+'])
		world->camera->moveCloser(-1);

	if (keyStates['-'])
		world->camera->moveCloser(1);

}

// Mouse click action
void Engine::mouseClick(int button, int state, int x, int y) {

	mouseX = x;
	mouseY = y;

	if (button == 1 && state == GLUT_DOWN)
		world->camera->switchView(-1);


	if (world->camera->type == ThirdPerson) {
		x = sizeX/2;
		y = sizeY/2;
	}

	if (button == 0 && state == GLUT_DOWN)
		world->pickObject(x, y);
}

// Mouse Move Action
void Engine::mouseMotion(int x, int y)
{

	if (mouseX < 0)
		return;

	int edge = 5;
	int deltaX = x - mouseX;
	int deltaY = y - mouseY;

	world->camera->rotateOX(deltaY * 0.5f);
	world->camera->rotateOY((float)deltaX);

	mouseX = x;
	mouseY = y;

	if (x > sizeX - edge)
		mouseX = sizeX/2;

	if (x < edge)
		mouseX = sizeX/2;

	if (y > sizeY - edge)
		mouseY = sizeY/2;

	if (y < edge)
		mouseY = sizeY/2;

	if (y < edge || y > (sizeY - edge) || x < edge || x > (sizeX - edge))
		glutWarpPointer(mouseX, mouseY);
}

// Mouse Scroll Action
void Engine::mouseWheelFunc(int wheel, int direction, int x, int y) {

	if (direction > 0)
		world->camera->moveCloser(-2);

	if (direction < 0)
		world->camera->moveCloser(2);
}

// Clip cursor inside window
void Engine::clipCursor() {
	clip_cursor = !clip_cursor;

	if (clip_cursor == false) {
		ClipCursor(0);
		return;
	}

	window.left = glutGet((GLenum)GLUT_WINDOW_X);
	window.top = glutGet((GLenum)GLUT_WINDOW_Y);
	window.bottom = window.top + sizeY;
	window.right = window.left + sizeX;

	ClipCursor(&window);
}

// Functie afisare
void Engine::display() {

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	//setup view
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	world->render();

	glutSwapBuffers();
}

// Timp rulare de la inceputul jocului
int Engine::getElapseTime() {
	 return glutGet(GLUT_ELAPSED_TIME);
}

void Engine::glutIdle() {
	int frame_start = getElapseTime();

	onKey();

	glutPostRedisplay();

/*
	elapse_time = getElapseTime() - frame_start;

	if ((float)1000/frames - elapse_time > 0)
		Sleep( DWORD ((float)1000/frames - elapse_time));
*/

}

// Reset Game
void Engine::reset() {

	level++;

	world = new World();
	world->init();

	for (int i=0; i<256; i++) {
		keyStates[i]=false;
		skeyStates[i]=false;
	}

}

// Reshape window
void Engine::reshape(int width, int height) {

	sizeX = width;
	sizeY = height;

	//set viewport
	glViewport(0, 0, width, height);

	//set proiectie
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45, (float)width/(float)height, 0.1f, 1000);

}

// Initializare Engine / Glut
void Engine::init(int argc, char **argv) {
	
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH | GLUT_MULTISAMPLE);

	//init window
	glutInitWindowSize(sizeX, sizeY);
	glutInitWindowPosition(450, 300);
	glutCreateWindow("Tema4");

	//callbacks
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyPressed);
	glutKeyboardUpFunc(keyUp);
	glutSpecialFunc(specialKeyPressed);
	glutSpecialUpFunc(specialKeyUp);

	glutIdleFunc(glutIdle);

	glutMouseFunc(mouseClick);
	glutMotionFunc(mouseMotion);
	glutPassiveMotionFunc(mouseMotion);
	glutMouseWheelFunc(mouseWheelFunc); 

	glEnable(GL_DEPTH_TEST);
	glShadeModel(GL_SMOOTH);

	glEnable(GL_COLOR_MATERIAL);
    glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);

	glEnable(GL_COLOR_MATERIAL);
	glEnable(GL_LIGHTING);

	glewInit();
	wglSwapIntervalEXT(1);

	glClearColor(0, 0, 0, 1.0);

	clipCursor();

	reset();

	glutWarpPointer(sizeX/2, sizeY/2);	

	glutMainLoop();	
}
