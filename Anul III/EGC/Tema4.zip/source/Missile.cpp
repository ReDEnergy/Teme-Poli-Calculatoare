#define _USE_MATH_DEFINES

#include "Missile.h"


Missile::Missile(char *file)
	: Object3D(file)
{
	init();
	createVBO();
	speed = 1;
}


Missile::Missile(Missile *A) 
	: Object3D(A)
{
	init();
}


Missile::~Missile() 
{
}

void Missile::init() {
	speed = 100;
	angle = 90;
	scale = 0.5f;
	target = NULL;
	position = Vector3D(0, 0, 0);
	rotate = Vector3D(0, 1, 0);
}

void Missile::draw() {

	glColor4f(1, 0, 0, 1);

	glTranslatef(position.x, position.y, position.z);
	glScalef(scale, scale, scale);

	glRotatef(angleOX, 1, 0, 0);
	glRotatef(angleOY, 0, 1, 0);
		drawVBO();
	glRotatef(-angleOY, 0, 1, 0);
	glRotatef(-angleOX, 1, 0, 0);

	glScalef(1/scale, 1/scale, 1/scale);
	glTranslatef(-position.x, -position.y, -position.z);

}

void Missile::setPosition(Vector3D pos) {
	position = pos;
}

void Missile::moveToTarget() {

	if (target == NULL)
		return;

	Vector3D dir = position - target->position;
	position -= dir.Normalize();

	angleOY = atan(dir.x/dir.z) * 180 / M_PI;

	angleOX = atan(dir.x / sqrt(dir.x * dir.x + dir.z * dir.z)) * 180 / M_PI;

	if (dir.y > 0 && dir.z > 0)
		angleOX *= -1;

	if (dir.z < 0 && dir.y < 0) {
		angleOX -= 90;
		angleOY -= 180;
	}

	if (dir.z < 0 && dir.y > 0)
		angleOY -= 180;

	if (position.Distance(target->position) < 1) {
		target->init();
		target = NULL;
	}

}

