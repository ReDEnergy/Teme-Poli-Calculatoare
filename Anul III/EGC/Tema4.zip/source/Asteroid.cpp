#include "Asteroid.h"

ColorPicker *CP = ColorPicker::getInstance();

Asteroid::Asteroid(char *file)
	: Object3D(file)
{

	angle = 0;
	type = 0;
	init();
	createVBO();
	pickcolor = CP->getPickColor();
}

Asteroid::Asteroid(Asteroid *A) 
	: Object3D(A)
{
	angle = 0;
	type = A->type;
	init();
	pickcolor = CP->getPickColor();
}


Asteroid::~Asteroid() 
{
}

void Asteroid::init() {

	selected = false;

	int sign[2] = {-1, 1};

	dir = Vector3D(1, 0, 0);

	speed = (float) rand() / RAND_MAX + 0.1f;

	float rx = (float) rand() / RAND_MAX;
	float ry = (float) rand() / RAND_MAX;
	float rz = (float) rand() / RAND_MAX;

	rotate = Vector3D(rx, ry, rz);

	rspeed = (float) rand() / RAND_MAX;
	if (rspeed > 0.5f)
		rspeed -=0.5f;

	float py = (float) rand() / RAND_MAX * 50 * sign[rand() % 2];
	float pz = (float) rand() / RAND_MAX * 100 * sign[rand() % 2];

	position = Vector3D(-200, py, pz);

	scale = 0;
	while (scale < 0.2f)
		scale = (float) rand() / RAND_MAX;

}

void Asteroid::draw(int target = 0) {

	if (type)
		glColor4f(0.3f, 0.8f, 0.8f, 1);
	else 
		glColor4f(0.3f, 0.3f, 0.3f, 1);

	if(selected)
		glColor4f(1, 1, 1, 0.2f);

	if (target == 2)
		glColor3f(pickcolor.x/255.0f, pickcolor.y/255.0f, pickcolor.z/255.0f);

	glTranslatef(position.x, position.y, position.z);
	glRotatef(angle, rotate.x, rotate.y, rotate.z);
	glScalef(scale, scale, scale);

		drawVBO();

	if (target == 1)
		drawCage();

	glScalef(1/scale, 1/scale, 1/scale);
	glRotatef(-angle, rotate.x, rotate.y, rotate.z);
	glTranslatef(-position.x, -position.y, -position.z);

}

void Asteroid::travel() {

	position += dir * speed;
	angle += rspeed;

	if (position.x > 200)
		init();

};
