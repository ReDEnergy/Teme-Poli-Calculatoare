//2.2 Utilisation avec index buffer fa�on Vertex Array

#include "VBO.h"

VBO::VBO(int nr_vertices, GLfloat *vertices, GLfloat *normals)
	: nr_vertices(nr_vertices)
{

	GLenum target = GL_ARRAY_BUFFER;
	GLenum usage = GL_STATIC_DRAW;

	size = nr_vertices * sizeof(GLfloat) * 6;

	vboId = 0;  // 0 is reserved, glGenBuffers() will return non-zero id if success

    glGenBuffers(1, &vboId);					// create a vbo
    glBindBuffer(target, vboId);				// activate vbo id to use
    glBufferData(target, size, NULL, usage);	// allocate memory for data

    // check data size in VBO is same as input array, if not return 0 and delete VBO
    int bufferSize = 0;

	glGetBufferParameteriv(target, GL_BUFFER_SIZE, &bufferSize);

	if(size != bufferSize)
    {
        glDeleteBuffers(1, &vboId);
        vboId = 0;
        cout << "[createVBO()] Data size is mismatch with input array\n";
    }

	glBufferSubData(target, 0, size/2, vertices);
	glBufferSubData(target, size/2, size/2, normals);
}


void VBO::draw()
{

    // save the initial ModelView matrix before modifying ModelView matrix
    glPushMatrix();

		// bind VBOs with IDs and set the buffer offsets of the bound VBOs
		// When buffer object is bound with its ID, all pointers in gl*Pointer()
		// are treated as offset instead of real pointer.
		glBindBuffer(GL_ARRAY_BUFFER, vboId);

		// enable vertex arrays
		glEnableClientState(GL_VERTEX_ARRAY);
		glEnableClientState(GL_NORMAL_ARRAY);

		// before draw, specify vertex and index arrays with their offsets
		glVertexPointer(3, GL_FLOAT, 0, 0);
		glNormalPointer(GL_FLOAT, 0, (void*)(size/2));

		glDrawArrays(GL_TRIANGLES, 0, nr_vertices);

		glDisableClientState(GL_VERTEX_ARRAY);   // disable vertex arrays
		glDisableClientState(GL_NORMAL_ARRAY);

		// it is good idea to release VBOs with ID 0 after use.
		// Once bound with 0, all pointers in gl*Pointer() behave as real
		// pointer, so, normal vertex array operations are re-activated
		glBindBuffer(GL_ARRAY_BUFFER, 0);

    glPopMatrix();
}