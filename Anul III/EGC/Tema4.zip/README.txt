EGC - Tema 4
    SpaceEscape
    Ivanica Gabriel 333CA

====================================================================================

Cuprins

	1. Cerinta
	2. Utilizare
	3. Implementare
	4. Testare
	5. Probleme Aparute
	6. Continutul Arhivei
	7. Functionalitati

====================================================================================


1. Cerinta

Sa se Imperiul Contraataca (SpaceEscape 2012)


====================================================================================
2. Utilizare

	2.1 Compilare si Rulare
		Se compileaza programul si se copiaza executabilul din Debug/Release in folderul parinte
		Se ruleaza executabilul Tema4.exe din folderul parinte (Tema4).
		
		Nu este nevoie de parametrii suplimentari
		
		Probabil din cauza citirii din fisier fara strem-uri dureaza destul de mult pana sunt
		incarcate toate obiectele neceasre in timpul jocului. (vreo 5 secunde)
		
	2.2 Input Tastatura

	Camera se poate roti utilizand mouse-ul.

			'W'	-	miscare nava/camera in fata
			'A'	-	miscare nava/camera in stanga
			'S'	-	miscare nava/camera in spate
			'D'	-	miscare nava/camera in dreapa
			'E' -	miscare nava/camera in jos
		'SPACE' -	miscare nava/camera in sus

			'8'	-	miscare nava in fata
			'5'	-	miscare nava in spate
			'4'	-	miscare nava in stanga
			'6'	-	miscare nava in dreapta
			'7'	-	miscare nava in jos
			'9'	-	miscare nava in sus

  'MiddleClick' -	alternare intre First Person si Third Person View
			'1'	-	camera First Person
			'2'	-	camera Third Person
			'3'	-	camera Top View
  
			'C'	-	mentine cursorul mouse-ului in fereastra de joc
			'R'	-	resetare joc
		
			'+'	-	zoom + (departare de erou)
			'-'	-	zoom - (apropiere de erou)
	
			'*'	-	crestere viteza de deplasare
			'/'	-	scadere viteza de deplasare

			'N' -	schimbare camera free/nava
			'M' -	schimabre camera free/asteroid
			'J' -	afisare spatiu de coliziune/periculos
			'L' -	activare/dezactivare lumini omnidirectionale

====================================================================================

	3. Implementare

		Platforma: Windows 7 x64 SP1, Microsoft Visual Studio 2010
		Biblioteci FreeGlut - framework-ul de la laborator


		Spatiu:
		**********************************************************************************
			
			Toate obiectele din joc cu exceptia celor de baza din glut au fost importate din
		fisiere .obj si randate folosind VBO-uri. Pentru importare am parsat fisierului .obj

			Folosesc 3 tipuri de Asteroizi ce au parametrii dinamici :
				- dimensiune
				- viteza
				- forma
				- pozitie de aparitie

			In scena pot fi adaugate un numar foarte mare de asteroizi (testat cu 1500).
			Toti asteroizii sunt resetati cand ajung la marginea spatiului de joc.
			Se utilizeaza acceleasi instante de obiecte, resetanduse doar parametrii acestora.


		Camera:
		**********************************************************************************
	
			Camera folosita este cea din Tema3 cu pozibilitatea de a instantia camera si comutare
		intre mai multe instante de camera.

			Miscarea se poate face pe toate cele 3 axe OX, OY, OZ.


		Coliziuni:
		**********************************************************************************

			Coliziunile sunt implementate "rudimentar" cu sfere de coliziune intre asteroizi
		si nava si intre rachete si asteroizi

		
		Lumini:
		**********************************************************************************
			2 lumini omnidirectionale de culoare diferita
			4 lumini de tip SpotLight pe nava
			
			
		Bonusuri:
		**********************************************************************************
			Toate obiectele sunt incarcate si randate folosind VBO-uri
			Selectia obiectelor realizata prin selectia culorii unice
			3 Tipuri de asteroizi
			Exista intotdeauna un numar constant de asteroizi si o distributie eficienta
		pentru a avea ce sa fie evitat
			Obiectul selectat este colorat transparent pentru a putea pozitiona foarte usor
		camera in centrul acestuia si a privi catre nava
			Cadourile cresc nivelul scutului
			Nava nu trage cu lasere ci cu rachete - fizica rudimentara de heat missile
			Racketele sunt obiecte importate.
			
	3.1 Diagrama Clase

	+--Object3D ---		Asteroid
				---		Player
				---		Missile	
	+--Light
	+--Engine
	+--World
	+--Cell
	+--Maze
	+--Camera
	+--Player
	+--ColorPicker

====================================================================================

4. Testare

	Platforma: Windows 7 x64 SP1, Microsoft Visual Studio 2010
				i5 2500K, 8GB RAM, HD6950

	Cat se poate de mult pe parcurul dezvoltarii temei. Sunt destule probleme unele mai marunte
	altele mai mari dar totul acceptabil si in concordanta cu tema.


====================================================================================

5. Probleme aparute
	
	-	Fizica de joc in special la rachete - arata acceptabil :D - probleme cand se trage 
		pe x negativ

	-	Fizica de coliziune implementata rudimentar - sfere de coliziune
	-	Nu am implementat coliziune intre asteroizi - se vede foarte bine oricum :D

	-	Probleme cu luminile - lumina spot pare sa randeze in functie de inclinarea camerei

	-	multe multe si marunte
		Nu apasa N cand e activata camera asteroid
		Nu apasa M cand e activata camera nava

====================================================================================

6. Continutul Arhivei

		include.h

		Main.cpp
		Asteroid.cpp	+ Asteroid.h
		ColorPicker.cpp	+ ColorPicker.h
		Object3D.cpp	+ Object3D.h

		VBO.cpp		+ VBO.h
		Engine.cpp	+ Engine.h
		World.cpp	+ World.h
		Camera.cpp	+ Camera.h
		Player.cpp	+ Player.h
		Missile.cpp	+ Missile.h
		Light.cpp	+ Light.h

		Vector3D.h
		Vectir4D.h
		
		README.txt

====================================================================================

7. Functionalitati

		Functionalitati Standard (ca in enunt)
			-	Camera Dinamica/Statica/Asteroid
			-	Iluminare 6 surse - 2 omni, 4 spot pe nava
			-	Nava importata din fisier .OBJ
			-	Distrugere Asteroizi

		Functionalitati Bonus
			-	Tipuri diferite de asteroizi
			-	Folosite VBO pentru randarea obiectelor
			-	Selectia obiectelor bazata pe culoare unica
			-	Asteroizii sunt generati constant si distribuiti eficient
			-	Power ups - cadouri ce cresc scutul navei
			-	In loc de lasere nava trage cu Rackete + fizica Rackete
			-	Asteroizii selectati sunt devin transparenti - benefic pentru camera asteroid
		
