function test_grafic(eps)
	%	Functia primeste valoare eps a erorii pentru calculul interpolantilor
	%	Clear plot
	clf;
	%	Se face plot la fiecare interpolant
	%	Se face plot la ultimul grafic specific fiecarui intpolant
	%	pentru care Erroarea de calcul e mai mica decat < eps
	%	Pentru interpolantii care nu converg (Lagrange si Newton) pentru o 
	%	anumita valoarea a lui eps , se face plot la ultimul calcul al 
	%	polinoamelor pentru care Eroarea < Eroarea precedenta
	
	for i = 1:6
		%	Plotarea polinoamelor calculate in cazul continuu
		hold on;
		subplot( 1, 2, 1 );
		eval_interpolator_c( i, eps);
	  
  		%	Plotarea polinoamelor calculate in cazul discret
		hold on;
		subplot( 1, 2, 2 );
		eval_interpolator_d( i, eps);
		
	end
end
