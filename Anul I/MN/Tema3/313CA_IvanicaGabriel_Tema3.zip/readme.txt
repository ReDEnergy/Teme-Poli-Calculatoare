Ivanica
Gabriel
313CA
							Tema 4 MN - INTERPOLARE
							
		%	Convergenta polinoame de interpolare - functie continua
		

	Pe cazul contiunuu fucntiile spline naturale , sau tensionate au cea mai 
rapida convergenta catre 0. (cand eps tinde la 0) 
	Datorita faptului ca suportul de interpolare este reprezentat de puncte 
echidistante interpolarile Lagrange si Newton au erori foarte mari in capetele
de interpolare, osciland foarte mult pentru un suport de interpolare cu mai mult
de 60 de puncte. (http://en.wikipedia.org/wiki/Runge%27s_phenomenon).
	Pentru a maximiza eficientei la interpolarile Lagrange si Newton ar trebui
folosite noduri Chebasev.

	Testand convergenta pentru diferite erori 0.1, 0.01 , 0.001 , 0.0001 se 
poate observa ca interpolarile spline sunt singurele ce converg pentru o eroare
foarte mica ( este necesar un suportrt de intepolare mai mare , 2^10 
puncte sau chiar mai mult o data cu scaderea eroarii eps )
	Pentru testare se poate adauga puterea pow ca parametru al functiei test.
In cazul in care nu se da un parametru pow se va considera pow=6 


		%	Convergenta polinoame de interpolare - functie discreta
		
	Functia discreta are abcisele tot echidistante si datorita numarului mare
300 de puncte interpolarile Lagrange si Newton v-or da erori extrem de mari la 
capetele functiei. (oscilatii foarte mari).

	De asemenea calculul unei erori pentru o functie discrata nu se poate 
realiza deoarce nu este o functie continua si nu putem sti valoarea functiei in
punctele cerute la interpolare.
	Datorita faptului ca interpolarile spline naturale sau tensionate converg 
spre 0 cel mai repede pentru o functie continua, o modalitate de a calcula
eroarea la o functie discreta este sa consideram ca interpolarea cu spline 
(naturale sau tensionate) reprezinta functia initiala la care se dau cele 300 
de puncte suport de intepolare.
	Astfel se considera ca interpolarea spline este functia initiala , deci 
are eroare 0 iar calculul erorilor celorlalte metode se face utilizand aceasta
functie.

	


	%	Bibliografie

	Libraria de functii pentru Lagrange si Newton
	Spline tensionate si naturale - cartea de MN Valeriu Iorga (functiile sunt
scrie pentru suport echidistant)
	Interpolarea fourier - carte de MN + website
	http://dmpeli.mcmaster.ca/Matlab/Math1J03/LectureNotes/Lecture3_4.htm		

 

