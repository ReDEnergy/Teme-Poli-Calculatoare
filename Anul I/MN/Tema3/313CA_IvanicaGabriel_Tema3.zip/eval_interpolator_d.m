% 	Functia de evaluare a unui interpolant pe cazul discret
%	tip	-	tipul interpolatului 1:6
%	eps	-	eroarea de interpoalare

function N = eval_interpolator_d(tip, eps)

	load sunspot.dat

	%	x - abcisele in care se cunoaste functia f
	%	a - abcisele in care se face aproximare polinomiala

	x = sunspot(:,1);
	x = x';
	f = sunspot(:,2);
    f = f';

	a = linspace (x(1) ,x(300), 1001);

	switch (tip)
		case 1
			return;
		case 2
			return;	
		case 3
			b = Liniar_spline (a, x, f);
			name = "Liniare";
		case 4
			b = Natural_cubic_spline (a, x, f);
			name = "Naturale";
		case 5
			b = Spline_cubic_tensionate (a, x, f);
			name = "Tensionate";
		case 6
			x2 = linspace (-pi , pi, 301);
			a2 = linspace (-pi , x2(300), 1001);
			b = Fourrier (a2', x2', f');
			b = b';
			name = "Fourier";
		otherwise
			return;
	end

	plot (a,b,sprintf('%d;%s;', mod(tip+1,5)+1, name));

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%							 FUNCTII NECESARE								  %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	%	3)	Interpolare spline liniare

function sy = Liniar_spline (s, x, y)
	% sy(i) = a(i) * x(i) + b(i)
	% s = abscisele in care se calculeaza polinomul
	% x = abscisele celor N+1 puncte
	% y = ordonatele celor N+1 puncte

	N = length(s);
	n = length(x);

	a(1:n-1) = ( y(2:n) - y(1:n-1)) ./ (x(2:n)-x(1:n-1));
	b(1:n-1) = ( x(2:n) .* y(1:n-1) - x(1:n-1) .* y(2:n)) ./ (x(2:n)-x(1:n-1));

	% Calculul valorilor in punctele s 
	j=1;
	for i = 1 : N
		if s(i) > x(j+1)
			j=j+1;
		end
		sy(i) = a(j) * s(i) + b(j);
	end

end

	%	4)	Interpolare cubic spline

function sy = Natural_cubic_spline (s, x, y)
	%	x -	suport de interpolare
	%	y - valorea functiei in punctele suport
	%	s - valoarile in care se calculeaza polinomul
	%	a,b,c,d 	parametrii functiei
	%	sy (i) = d(i)*(x-x(i))^3 + c(i)*(x-x(i))^2 + b(i)*(x - x(i)) + a(i)

	n = length(x);

	a = y;
	h = x(2)-x(1);

	%	Sistemul de rezolvat	A * c = g
	
	dif = a(3:n) - 2 * a(2:n-1) + a(1:n-2);
	g(2:n-1) = 3 * dif / h;
	g(1) = 0; 	g(n) = 0;
 
	d1(1) = 1;		d1(n) = 1;	d1(2:n-1) = 4*h;
	d2(1) = 0;		d2(2:n-1) = h;
	d3(n-1) = 0;	d3(1:n-2) = h;
	A = diag(d1) + diag(d2,1) + diag(d3,-1);

	%	Rezolvarea sistemelor
	c= A\g';
	c = c';

	%	Calcularea polinoamelor
	m = n-1;
	d(1:m) = ( c(2:m+1) - c(1:m) ) / (3 * h);
	b(2:m) = ( a(2:m) - a(1:m-1) ) / h + ( c(1:m-1) + 2 * c(2:m) ) * h / 3;
	b(1) = b(2) - 3 * d(1) * h^2;

	%	Calculul valorilor in puncte
	sy = Calcul_polinoame (s,a,b,c,d,x);
	
end

	%	5)	Interpolare spline tensionate

function sy = Spline_cubic_tensionate (s, x, y)
	%	x -	suport de interpolare
	%	y - valorea functiei in punctele suport
	%	s - valoarile in care se calculeaza polinomul
	%	a,b,c,d 	parametrii functiei
	%	sy (i) = d(i)*(x-x(i))^3 + c(i)*(x-x(i))^2 + b(i)*(x - x(i)) + a(i)

	n = length(x);

	a = y;
	h = x(2)-x(1);

	%	Sistemul de rezolvat	A * c = g
	dif = a(3:n) - 2 * a(2:n-1) + a(1:n-2);
	g(2:n-1) = 3 * dif / h;

    f1_der = ( y(2) - y(1) ) / h;
	fn_der = ( y(n) - y(n-1) ) / h;

	g(1)   = 3 * ( ( y(2) - y(1) ) / h - f1_der );
	g(n)   = 3 * ( fn_der - ( y(n) - y(n-1) ) / h );

	d1(1) = 2*h;
	d1(n) = 2*h;
	d1(2:n-1) = 4*h;
   	d2(1:n-1) = h;
	d3(1:n-1) = h;
	A = diag(d1) + diag(d2,1) + diag(d3,-1);

	%	Rezolvarea sistemulul
	c = A\g';
	c = c';

	%	Calcularea polinoamelor
	m = n-1;
	d(1:m) = ( c(2:m+1) - c(1:m) ) / (3 * h);
	b(2:m) = ( a(2:m) - a(1:m-1) ) / h + ( c(1:m-1) + 2 * c(2:m) ) * h / 3;
	b(1) = f1_der;
	
	%	Calculul valorilor in puncte
	sy = Calcul_polinoame (s,a,b,c,d,x);
	
end

	%	6)	Interpolare trigonometrica Fourrier
function sy = Fourrier (s, x, y)
	N = length(s);
	n = length(x)-1;
	m = n/2;

	y = y';
	y(n+1)=0;

	% Calculez coeficientii polinomului trigonometric
	a = 2*y*cos(x*[0:m])/n;
	b = 2*y*sin(x*[0:m])/n;

	% Calculul valorilor polinomului in punctele cerute 
	sy = a(1)/2 * ones(N,1);
	for j = 1 : m-1
	 	sy = sy + cos(s*j) * a(j+1) + sin(s*j) * b(j+1);
	end
 	sy = sy + a(m+1) * cos(m*s);
end

	% 	Calcului polinomului pentru fiecare interpolant spline
function sy = Calcul_polinoame(s,a,b,c,d,x)
	N = length(s);
	j=1;
	for i = 1 : N
		if s(i) > x(j+1)
			j=j+1;
		end
		R = s(i)-x(j);
		sy(i) = d(j)* ( R^3 ) + c(j)*( R^2) + b(j) * (R) + a(j);
	end
end

