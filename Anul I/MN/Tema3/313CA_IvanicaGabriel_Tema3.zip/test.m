function M = test (eps,pow)
	%	Functia primeste valoarea eps a erorii pentru calculul interpolantilor
	%	pow	- numarul de iteratii 2^pow
	if nargin == 1
		pow = 6;
	end		
	
	%	Clear plot si plotarea tuturor functiilor intr-o singura fereastra
	clf;
	hold on;
	for i = 1 : 6	
		M(i,1) = eval_interpolator_c(i,eps,pow); 
	end	 

end
