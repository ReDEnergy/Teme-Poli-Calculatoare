function tema2(file,d,eps)
	
# Deschiderea fisierelor 
	out = sprintf ("%s.out",file);
	f2 = fopen (out,"w"); 
	f1 = fopen (file,"r"); 

# Citire n , val1 si val2
	
	n=fscanf(f1,"%d",1);
	for i=1:n+1
		skip = fgets(f1,300);
	endfor
	val1 = fscanf(file,"%f",1);
	val2 = fscanf(file,"%f",1);
	fclose(f1);

# Rezolvarea functiei u(x) - continua
	# a * val1 + b = 0
	# a * val2 + b = 1
	a = 1 / (val2-val1);	
	b = - a * val1 ;

# Calcularea vectorilor de PageRank folosind metodele de la TASK 1 si 2
	PR = Iterative (file,d,eps);
	PR2 = Algebraic (file,d,eps);

# Sortare PR2 - metoda bubble sort

	# Setarea vectorului de sortat
		PR1=PR2;
	# Se sorteaza si numarul nodului necesar la sfarsit		
		nod=1:n;
	# Sortare		
		g=1;	
		while (g)
			g=0;
			for j=1:n-1
				if ( PR1(j) < PR1(j+1) )
					g=1;
					aux = PR1(j);
					PR1(j) = PR1(j+1);
					PR1(j+1) = aux;
					aux = nod(j);
					nod(j) = nod(j+1);
					nod(j+1) = aux;
				endif
			endfor
		endwhile

# Afisare rezultate

	fprintf(f2,"%d\n",n);
	fprintf(f2,"%f\n",PR);
	fprintf(f2,"\n");
	fprintf(f2,"%f\n",PR2);	
	fprintf(f2,"\n");

	for i=1:n
		fprintf(f2,"%d %d ", i, nod(i));
		fprintf(f2,"%f\n", u(PR1(i), val1, val2, a, b) );
	endfor

# Inchidere fisier
	fclose(f2);

endfunction

function V = u(x,val1,val2,a,b)
	if ( x < val1 ) 
		V = 0;
		elseif ( x < val2 ) 
		V = a * x +b;
		elseif ( x >= val2 ) 
		V = 1;
	endif	 
endfunction
