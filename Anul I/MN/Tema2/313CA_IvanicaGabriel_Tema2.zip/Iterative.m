function RANK = Iterative(file,d,eps)
	
	# Deschiderea fisierelor 
	f=fopen(file,"r");

	# Citirea datelor si construirea grafului
	n = fscanf(file,"%d",1);

	A=zeros(n,n);
	for i=1:n
		fscanf(file,"%d",1);
		nr = fscanf(file,"%d",1);
		v = fscanf(file,"%d",nr);
		A(i,v)=1;
		A(i,i)=0;
	endfor

	# Matricea K inversata
	K=zeros(n,n);
	for i=1:n
		K(i,i)=1/sum(A')(i);
	endfor

	M=(K*A)';

	# Aplicare algoritm iterativ
	
	PR(1:n,1)=1/n;

	t=1;
	do 
		t++;
		PR(1:n,t)=d*M*PR(1:n,t-1) + (1-d)/n * ones (n,1);
	until ( abs(PR(1:n,t)-PR(1:n,t-1)) < eps )
	
	# Rezultat

	RANK = PR (1:n,t);

	# Inchiderea fisierului 
	fclose(f);

endfunction
