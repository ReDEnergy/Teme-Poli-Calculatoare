function RANK = Algebraic(file,d,eps)
	
	# Deschiderea fisierelor 
	f=fopen(file,"r");

	# Citirea datelor si construirea grafului
	n = fscanf(file,"%d",1);

	A=zeros(n,n);
	for i=1:n
		fscanf(file,"%d",1);
		nr = fscanf(file,"%d",1);
		v = fscanf(file,"%d",nr);
		A(i,v)=1;
		A(i,i)=0;
	endfor

	# Citire val1 si val2
	
	val1 = fscanf(file,"%d",1);
	val2 = fscanf(file,"%d",1);

	# Matricea K inversata si calcularea matricii M
	K=zeros(n,n);
	for i=1:n
		K(i,i)=1/sum(A')(i);
	endfor

	M=(K*A)';

	# Aplicare algoritm Algebraic
	
	I= eye(n);
	T= I -d*M;

	# Aplicare Gram - Schmidt

	Q = T;
	R = zeros(n,n);
	for k = 1:n
		R(k,k) = norm( Q(1:n,k) );
		Q(1:n,k) = Q(1:n,k) / R(k,k);
	   	for j=k+1 : n
			R(k,j) = Q(1:n,k)' * Q(1:n,j);
			Q(1:n,j) = Q(1:n,j) - Q(1:n,k) * R(k,j);
		endfor
	endfor


	# Rezolvare sistem superior triunghiular 
	# X = inv(T)
	# R * X = Q'
	# B = Q'
	X = zeros (n,n);
		# calcul termeni initiali
		B = Q';		
		for i=1:n
			X(n,i) = B(n,i) / R(i,n) ;		
		endfor

		# formula de recurenta  
		for i = n - 1 : -1 : 1
			X(i,1:n) = (B(i,1:n) - R(i,i+1:n) * X(i+1:n,1:n))/R(i,i);
        endfor

	# END SISTEM	X = inv (T)	

	# Calcularea vectorului PR - Algoritm ALGEBRAIC

	PR(1:n) = X * (1-d)/n * ones (n,1);

	RANK (1:n,1) = PR (1,1:n);

	# Inchiderea fisierului
	fclose(f);

endfunction
