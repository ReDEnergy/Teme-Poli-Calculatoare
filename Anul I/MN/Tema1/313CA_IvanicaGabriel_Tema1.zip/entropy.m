function entropy(file_in,a,b,c)
	# Deschiderea fisierelor 
	f=fopen(file_in,"r");
	f2=fopen("entropy.txt","w");	

	# Tipul fisierului
	type=fgets(f,3);
	# Comentariu
	com=fgets(f,100);

	# Numarul de linii n si de coloane m	
	n=fscanf(f,"%d",1);
	m=fscanf(f,"%d",1);

	# Valorea maxima (255)
	Vmax=fscanf(f,"%d",1);

	# Citirea matricii
	A=fscanf(f,"%d",[n,m]);

	# Bordarea matricii
	M=zeros(n+1,m+1);
	M(2:n+1,2:m+1)=A;

	# Calcularea valorii predictorului si a imaginii reziduale
	m1=M(1:n,2:m+1)	* a;
	m2=M(1:n,1:m)	* b;
	m3=M(2:n+1,1:m)	* c;

	P=m1+m2+m3;		# Preditor
	E=A-P;			# Imagine rezidua
	
	# Extragerea vectorului de valori unice
	u=unique(E);
	[k,k2]=size(u);	# k dimensiunea vectorului
	
	# Calcularea Entropiei
	S=0;			# entropia initiala
	for i=1:k	
		p(i)=sum(sum(E==u(i)))/(n*m);
		S=S-p(i)*log2(p(i));
	endfor;

	# Salvarea resultatului
	fprintf(f2,"Entropia este %.6f\n",S);
	fclose(f);
	fclose(f2);
endfunction
