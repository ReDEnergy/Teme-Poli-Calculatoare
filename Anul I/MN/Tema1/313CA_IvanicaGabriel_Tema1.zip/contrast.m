function contrast(file_in,a,b)

	# Deschiderea fisierelor 
	f=fopen(file_in,"r");
	f2=fopen("out_contrast.pgm","w");

	# Tipul fisierului
	type=fgets(f,3); # P2

	# Comentariu
	com=fgets(f,100);

	# Numarul de linii n si de coloane m	
	n=fscanf(f,"%d",1);
	m=fscanf(f,"%d",1);

	# Valorea maxima (255)
	Vmax=fscanf(f,"%d",1);

	# Citirea matricii
	A=fscanf(f,"%d",[n,m]);

	# Aflarea valorii minime si maxime din matricea A
	vmin=min(min(A));
	vmax=max(max(A));

	# Adaugarea efectului de contrast
	A=(b-a)*(A.-vmin)/(vmax-vmin)+a;

	# Conversie
	A=floor(A);
	A=uint8(A);
	
	# Salvarea resultatului
	fputs(f2,type);
	fprintf(f2,"%d %d\n",n,m);
	fprintf(f2,"%d\n",Vmax);
	fprintf(f2,"%d\n",A);
	fclose(f);
	fclose(f2);
endfunction
