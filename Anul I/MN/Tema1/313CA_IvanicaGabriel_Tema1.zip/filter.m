function filter(file_in,filter_type)

	# Deschiderea fisierelor 
	f=fopen(file_in,"r");
	f2=fopen("out_filter_type.pgm","w");

	# Tipul fisierului
	type=fgets(f,3);
	# Comentariu
	com=fgets(f,100);

	# Numarul de linii n si de coloane m	
	n=fscanf(f,"%d",1);
	m=fscanf(f,"%d",1);

	# Valorea maxima (255)
	Vmax=fscanf(f,"%d",1);

	# Citirea matricii
	A=fscanf(f,"%d",[n,m]);

	# Bordarea matricii
	M=zeros(n+2,m+2);
	M(2:n+1,2:m+1)=A;

	# Matrici de filtre si variabile
	smooth	=[ 1  1  1 ; 1  1  1 ; 1  1  1];
	blur	=[ 1  2  1 ; 2  4  2 ; 1  2  1];
	sharpen	=[ 0 -2  0 ;-2 11 -2 ; 0 -2  0];
	emboss	=[-1  0 -1 ; 0  4  0 ;-1  0 -1];

	offset=0;

	# Determinarea filtrului aplicat
	if(strcmp(filter_type,"smooth"))	x=smooth;	endif;
	if(strcmp(filter_type,"blur"))		x=blur;		endif;
	if(strcmp(filter_type,"sharpen"))	x=sharpen;	endif;
	if(strcmp(filter_type,"emboss"))		
		x=emboss;	
		offset=127;
	endif;

	# Calcularea factorului de imapartire
	factor=sum(sum(x));
	if(factor==0) factor=1;
	endif;

	# Calcularea matricilor ce v-or alcatui rezultatul final
	m1=M(1:n,1:m)	  *	x(1,1);
	m2=M(1:n,2:m+1)	  *	x(1,2);
	m3=M(1:n,3:m+2)	  *	x(1,3);
	m4=M(2:n+1,1:m)	  *	x(2,1);
	m5=M(2:n+1,2:m+1) *	x(2,2);
	m6=M(2:n+1,3:m+2) *	x(2,3);
	m7=M(3:n+2,1:m)	  *	x(3,1);
	m8=M(3:n+2,2:m+1) *	x(3,2);
	m9=M(3:n+2,3:m+2) *	x(3,3);

	# Determinarea rezultatului
	R=m1+m2+m3+m4+m5+m6+m7+m8+m9;
	R=R/factor+offset;

	# Conversie
	R=floor(R);
	R=uint8(R);

	# Salvarea resultatului
	fputs(f2,type);
	fprintf(f2,"%d %d\n",n,m);
	fprintf(f2,"%d\n",Vmax);
	fprintf(f2,"%d\n",R);
	fclose(f);
	fclose(f2);
endfunction
