/*
 * PROGRAMAREA CALCULATOARELOR
 * Evaluator Tema 3 de casa (Ce avem acolo, domnule Crusher?)
 *
 * (C) Florin Pop, florin.pop@cs.pub.ro
 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define LINE_LEN 30000
#define VECT_LEN 1000
#define SEPARATOR " secvente de "

int GetInt(char *str, int len)
{
	int res = 0;
	while (len)
	{
		res = res << 1;
		if (*str != '0' && *str != '1')
			return -1;
		res = res | (*str - '0');

		str ++;
		len --;
	}

	return res;
}

int IsParsable(char *str)
{
	while (*str)
	{
		if (!isspace(*str) && !iscntrl(*str))
			return 1;
		str++;
	}
	return 0;
}

int CompareSequences(char *s1, char *s2)
{
	int v1[VECT_LEN];
	int v2[VECT_LEN];
	char *p1, *p2;
	int i, j, tmp;

	v1[0] = 0;
	v2[0] = 0;
	p1 = s1;

	//Building the vectors...
	while (p1)
	{
		p2 = strchr(p1, ',');

		v1[0] ++;
	
		v1[v1[0]] = (p2) ? GetInt(p1, p2-p1) : GetInt(p1, strlen(p1));
		if (v1[v1[0]] < 0)
			return 0;

		if (p2)
			p1 = p2+1;
		else
			p1 = p2;
	}

	p1 = s2;
	while (p1)
	{
		p2 = strchr(p1, ',');

		v2[0] ++;

		v2[v2[0]] = (p2) ? GetInt(p1, p2-p1) : GetInt(p1, strlen(p1));

		if (v2[v2[0]] < 0)
			return 0;

		if (p2)
			p1 = p2+1;
		else
			p1 = p2;
	}

	//Sorting the vectors...
	for (i=1; i<=v1[0]-1; i++)
		for (j=i+1; j<=v1[0]; j++)
			if (v1[i] > v1[j])
			{
				tmp = v1[i];
				v1[i] = v1[j];
				v1[j] = tmp;
			}
	for (i=1; i<=v2[0]-1; i++)
		for (j=i+1; j<=v2[0]; j++)
			if (v2[i] > v2[j])
			{
				tmp = v2[i];
				v2[i] = v2[j];
				v2[j] = tmp;
			}

	//Comparing the vectors...
	if (v1[0] != v2[0])
		return 0;
	for (i=1; i<=v1[0]; i++)
		if (v1[i] != v2[i])
			return 0;

	//Everything is ok..
	return 1;
}

int CompareFiles(FILE *f1, FILE *f2)
{

#define SHOWERROR if (res) printf("These lines are invalid: "); \
	printf("%d ", crline)

	char crline1[LINE_LEN+1];
	char crline2[LINE_LEN+1];
	char *seppos1, *seppos2;
	int val1, val2;
	int res = 1, crline = 0;
	
	while (!feof(f1) && !feof(f2))
	{
		crline++;

		if (!fgets(crline1, LINE_LEN, f1))
			crline1[0]='\0';

		if (!fgets(crline2, LINE_LEN, f2))
			crline2[0]='\0';

		if (!IsParsable(crline1) && !IsParsable(crline2))
			continue;

		seppos1 = strstr(crline1, "\n");
		if (seppos1)
			*seppos1 = '\0';
		seppos2 = strstr(crline2, "\n");
		if (seppos2)
			*seppos2 = '\0';

		seppos1 = strstr(crline1, SEPARATOR);
		seppos2 = strstr(crline2, SEPARATOR);
		if (!seppos1 || !seppos2 || (seppos1-crline1 != seppos2-crline2))
		{
			SHOWERROR;
			res = 0;
			continue;
		}

		if (sscanf(crline1, "%d", &val1)<1)
		{
			SHOWERROR;
			res = 0;
			continue;
		}
		if (sscanf(crline2, "%d", &val2)<1)
		{
			SHOWERROR;
			res = 0;
			continue;
		}

		if (val1!=val2)
		{
			SHOWERROR;
			res = 0;
			continue;
		}

		if (!CompareSequences(seppos1 + strlen(SEPARATOR), seppos2 + strlen(SEPARATOR)))
		{
			SHOWERROR;
			res = 0;
			continue;
		}
	}
	if (!feof(f1))
	{
		if (!fgets(crline1, LINE_LEN, f1))
			crline1[0] = '\0';
		if (IsParsable(crline1))
			return 0;
	}
	if (!feof(f2))
	{
		if (!fgets(crline2, LINE_LEN, f2))
			crline2[0] = '\0';
		if (IsParsable(crline2))
			return 0;
	}

	printf("\n");
	return res;

#undef SHOWERROR
	
}

int main(int argc, char *argv[])
{
	FILE *f1, *f2;
	if (argc<3)
	{
		printf("Usage:\n");
		printf("%s file1 file2\n", argv[0]);
		printf("\n");
		printf("where file1 and file2 are the names of the files to be compared.\n");
		return 0;
	}

	f1 = fopen(argv[1], "r");
	if (!f1)
	{
		printf("%s could not be opened\n", argv[1]);
		return 1;
	}

	f2 = fopen(argv[2], "r");
	if (!f2)
	{
		printf("%s could not be opened\n", argv[2]);
		fclose(f1);
		return 1;
	}

	if (CompareFiles(f1, f2))
	{
		printf("The files are equivalent");
	}
	else
	{
		printf("The files are different");
	}

	fclose(f1);
	fclose(f2);
		
	return 0;
}
