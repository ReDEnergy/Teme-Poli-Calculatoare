/*
 * PROGRAMAREA CALCULATOARELOR
 * Evaluator Tema 3 de casa (Ce avem acolo, domnule Crusher?)
 *
 * (C) Florin Pop, florin.pop@cs.pub.ro
 */

#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	FILE *f;
	int n, a, b, i;
	if(argc!=2)
	{
		fprintf(stderr,"usage: %s nume_fisier", argv[0]);
		return -1;
	}
	
	if((f=fopen(argv[1],"wt"))==NULL)
	{
		fprintf(stderr,"error: can not create file %s",argv[1]);
		return -1;
	}
	
	printf("lungimea secventei: "); scanf("%d",&n);
	printf("a: "); scanf("%d",&a);
	printf("b: "); scanf("%d",&b);
	
	fprintf(f,"%d %d\n",a,b);
	
	srand((unsigned int)time(NULL));
	for(i=0;i<n;i++)
		fprintf(f,"%d",rand()%2);
	
	fclose(f);
	fprintf(stdout,"\nyour file is done.");
	return 0;
}
