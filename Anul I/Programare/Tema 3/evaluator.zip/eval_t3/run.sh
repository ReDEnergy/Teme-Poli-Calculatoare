#!/bin/bash

## compilarea temei
gcc -o tema3 tema3.c -Wall

if ! [ -f "tema3" ] ; then
    echo "Compilarea temei 4 a esuat :("
    exit 1
fi

## compilarea evaluatorului
gcc -o eval_t3 eval_t3.c -Wall

if ! [ -f "eval_t3" ] ; then
    echo "Compilarea evaluatorului a esuat :("
    exit 1;
fi

## rularea temei pentru fiecare test din directorul tests si evaluarea rezultatul
for i in `ls tests`
do
    echo -n "Testul [$i]:"
    
    # pentru testul i
    cp tests/$i secv.txt
    ./tema3
    
    if ! [ -f "rez.txt" ] ; then
	echo "Tema nu a generat fisierul de iesire :("
	exit 1;
    fi
    
    # evaluarea rezultatului
    result=`./eval_t3 rez.txt results/$i | tr -d '\n'`
    [[ "$result" = "The files are equivalent" ]]  && echo "   DONE"
    [[ "$result" != "The files are equivalent" ]] && echo "   FAILED"
    
done

## sterge fisierele create in vederea evaluarii temei
rm -rf rez.txt secv.txt tema3 eval_t3
